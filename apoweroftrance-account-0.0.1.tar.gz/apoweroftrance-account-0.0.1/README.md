# apoweroftrance-account

# secret.json

- SECRET_KEY: DJango secret key
- JWT_SECRET_KEY: secret key for JWT auth. if you designed for microservice. each service must have same key
- AES_KEY: 32 bit AES256 key
- AES_SECRET: 16 bit AES256 key
- EMAIL_HOST_USER: use for sending email
- EMAIL_HOST_PASSWORD: send email account's password